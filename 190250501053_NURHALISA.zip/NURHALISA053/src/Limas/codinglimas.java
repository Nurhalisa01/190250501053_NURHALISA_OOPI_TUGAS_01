/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limas;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author WIN -8
 */
public class codinglimas {
     public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Limas.proseslimas Limas= new Limas.proseslimas();
        try 
        {
            System.out.println("Masukkan Nilai Luas Limas");
            String l = dataIn.readLine();
            Limas.setLuas(Integer.parseInt (l));
            
            System.out.println("Masukkan Nilai Tinggi Limas");
            String b = dataIn.readLine ();
            Limas.setTinggi(Integer.parseInt (b));
            
            System.out.println("Luas luas LIMAS="+Limas.getLuas());
            System.out.println("Tinggi LIMAS="+Limas.getTinggi ());
            System.out.println("Volume LIMAS="+Limas.hitungVolume ());
        }
       
        catch (IOException e)
        {
            System.out.println("Data yang di input salah");
        }
     }
    
}
