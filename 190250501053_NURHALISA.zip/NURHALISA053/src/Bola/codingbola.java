/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bola;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author WIN -8
 */
public class codingbola {
     public static void main(String[]args)throws IOException {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Bola.prosesbola Bola = new Bola.prosesbola ();
        try          
    {
        System.out.println("Masukkan Jarijari");
            String s = dataIn.readLine();
            Bola.setJari(Integer.parseInt (s));
            
          
            System.out.println("Jarijari Bola="+Bola.getJari());
            System.out.println("Volume Bola="+Bola.hitungVolume ());
    }
         catch (IOException e)        
        {
          System.out.println("Data yang di input salah");
        }
        
    }
    
}
        
   