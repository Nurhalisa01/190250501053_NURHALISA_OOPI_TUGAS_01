/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabung;


/**
 *
 * @author WIN -8
 */
public class prosestabung {
    private int Jari;
    private int Tinggi;
    
    public void setJarijari (int Jarijari )
    {
        this.Jari = Jarijari;
    }
    public void set(int tinggi)
    {
        this.Tinggi=tinggi;
    }
    public int getJarijari()
    {
        return Jari;
    }
    public int gettinggi()
    {
        return Tinggi;       
    }
        public double hitungVolume()
        {
            double Volume;
            Volume=1/3*Jari*Jari*Tinggi;
            return Volume;
        }
            void settinggi (int parseint) {
                throw new UnsupportedOperationException("not support yet."); 
            }
   
    }
    

