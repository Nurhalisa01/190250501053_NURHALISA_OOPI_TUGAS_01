/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Balok;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author WIN -8
 */
public class codingbalok {
    public static void main(String[]args)throws IOException{
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Balok.prosesbalok Balok= new Balok.prosesbalok ();
        try 
    {
        System.out.println("inputkan Panjang");
        String p = dataIn.readLine();
        Balok.setPanjang(Integer.parseInt (p));
        
        System.out.println("inputkan Lebar");
        String l = dataIn.readLine ();
        Balok.setLebar(Integer.parseInt (l));
        
        System.out.println("inputkan tinggi");
        String t = dataIn.readLine ();
        Balok.setTinggi(Integer.parseInt (t));
    
        System.out.println("Panjang Balok="+Balok.getPanjang());
        System.out.println("Lebar Balok="+Balok.getLebar ());
        System.out.println("Tinggi Balok="+Balok.getTinggi ());
        System.out.println("Volume Balok="+Balok.hitungVolume ());
        
     }
         catch(IOException e)
    
    {
        System.out.println("Data yang di input salah");
         }
    }
}

